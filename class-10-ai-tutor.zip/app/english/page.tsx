import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Languages, BookText, PenTool, FileEdit, BookOpen, CheckCircle2 } from "lucide-react"

export default function EnglishPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-chart-4 flex items-center justify-center">
                  <Languages className="w-6 h-6 text-background" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">English</h1>
                  <p className="text-xs text-muted-foreground">Class 10 NCERT</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-chart-4/5 border-chart-4/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Welcome to English</CardTitle>
              <CardDescription className="text-base">
                Master reading, writing, grammar, and literature to express yourself clearly and confidently.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                <p className="font-semibold text-foreground">Why is English important?</p>
                <ul className="list-disc list-inside space-y-2 ml-2">
                  <li>Communicate clearly in writing and speaking</li>
                  <li>Understand stories, poems, and express your thoughts</li>
                  <li>Essential for exams, higher studies, and jobs</li>
                  <li>Opens doors to knowledge from around the world</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Tabs */}
        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="literature" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="literature" className="flex items-center gap-2 text-xs sm:text-sm">
                <BookText className="w-4 h-4" />
                <span>Literature</span>
              </TabsTrigger>
              <TabsTrigger value="grammar" className="flex items-center gap-2 text-xs sm:text-sm">
                <PenTool className="w-4 h-4" />
                <span>Grammar</span>
              </TabsTrigger>
              <TabsTrigger value="writing" className="flex items-center gap-2 text-xs sm:text-sm">
                <FileEdit className="w-4 h-4" />
                <span>Writing</span>
              </TabsTrigger>
            </TabsList>

            {/* Literature Tab */}
            <TabsContent value="literature">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Literature - First Flight & Footprints</h2>
                <p className="text-muted-foreground">Stories, poems, and lessons from great writers</p>
              </div>

              <div className="space-y-6">
                {/* Prose Section */}
                <div>
                  <h3 className="text-xl font-semibold mb-4">Prose (Stories & Lessons)</h3>
                  <Accordion type="single" collapsible className="space-y-4">
                    {/* A Letter to God */}
                    <AccordionItem value="prose-1" className="border rounded-lg px-4 bg-card">
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-start gap-3 text-left">
                          <Badge className="mt-1 bg-chart-4 text-background">Ch 1</Badge>
                          <div>
                            <h3 className="font-semibold text-lg">A Letter to God</h3>
                            <p className="text-sm text-muted-foreground">by G.L. Fuentes</p>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-4 space-y-4">
                        <div className="space-y-4 pl-2">
                          <div>
                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                              <BookOpen className="w-4 h-4 text-chart-4" />
                              Story Summary
                            </h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              Lencho is a farmer whose crops get destroyed by hailstorm. He has strong faith in God and
                              writes a letter asking for 100 pesos. The postmaster and employees collect money and send
                              it to him. But Lencho gets angry thinking post office people stole some money.
                            </p>
                          </div>

                          <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                            <h4 className="font-semibold">Key Themes & Messages:</h4>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Faith in God:</strong> Lencho's unshakeable belief
                                </div>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Irony:</strong> He trusts God but doesn't trust humans who helped him
                                </div>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Kindness:</strong> Post office employees show humanity
                                </div>
                              </li>
                            </ul>
                          </div>

                          <div>
                            <h4 className="font-semibold mb-2">Important Words:</h4>
                            <div className="space-y-1 text-sm">
                              <p>
                                <strong>Hailstorm:</strong> Storm with balls of ice falling from sky
                              </p>
                              <p>
                                <strong>Pesos:</strong> Currency (money)
                              </p>
                              <p>
                                <strong>Conscience:</strong> Sense of right and wrong
                              </p>
                            </div>
                          </div>

                          <div className="bg-chart-4/10 border border-chart-4/20 p-4 rounded-lg">
                            <h4 className="font-semibold mb-2">Exam Tip:</h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              Character sketch of Lencho is frequently asked. Understand the irony in the story. Be
                              ready to answer: Why was Lencho angry? What does the story teach us?
                            </p>
                          </div>

                          <Button className="w-full sm:w-auto bg-chart-4 text-background hover:bg-chart-4/90" asChild>
                            <Link href="/english/prose-1">Read Full Summary & Questions</Link>
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* Nelson Mandela */}
                    <AccordionItem value="prose-2" className="border rounded-lg px-4 bg-card">
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-start gap-3 text-left">
                          <Badge className="mt-1 bg-chart-4 text-background">Ch 2</Badge>
                          <div>
                            <h3 className="font-semibold text-lg">Nelson Mandela: Long Walk to Freedom</h3>
                            <p className="text-sm text-muted-foreground">Autobiography excerpt</p>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-4 space-y-4">
                        <div className="space-y-4 pl-2">
                          <div>
                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                              <BookOpen className="w-4 h-4 text-chart-4" />
                              What is it about?
                            </h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              Nelson Mandela became the first Black President of South Africa after years of struggle
                              against apartheid (racial discrimination). The chapter describes his inauguration ceremony
                              and thoughts about freedom and equality.
                            </p>
                          </div>

                          <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                            <h4 className="font-semibold">Key Themes:</h4>
                            <ul className="space-y-2 text-sm">
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Courage:</strong> Fighting for justice despite difficulties
                                </div>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Equality:</strong> All humans deserve equal rights regardless of color
                                </div>
                              </li>
                              <li className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                                <div>
                                  <strong>Forgiveness:</strong> Mandela forgave his oppressors
                                </div>
                              </li>
                            </ul>
                          </div>

                          <div className="bg-chart-4/10 border border-chart-4/20 p-4 rounded-lg">
                            <h4 className="font-semibold mb-2">Exam Tip:</h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              Know what apartheid means. Understand Mandela's idea of freedom. Be ready to write about
                              his courage and the values he stood for.
                            </p>
                          </div>

                          <Button className="w-full sm:w-auto bg-chart-4 text-background hover:bg-chart-4/90" asChild>
                            <Link href="/english/prose-2">Read Full Summary & Questions</Link>
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* More Prose */}
                    <Card className="bg-muted/50">
                      <CardContent className="pt-6">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 3</Badge>
                            <span>Two Stories about Flying</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 4</Badge>
                            <span>From the Diary of Anne Frank</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 5</Badge>
                            <span>The Hundred Dresses - Part 1 & 2</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 6</Badge>
                            <span>Glimpses of India</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 7</Badge>
                            <span>Mijbil the Otter</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 8</Badge>
                            <span>Madam Rides the Bus</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 9</Badge>
                            <span>The Sermon at Benares</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Ch 10</Badge>
                            <span>The Proposal</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Accordion>
                </div>

                {/* Poetry Section */}
                <div>
                  <h3 className="text-xl font-semibold mb-4">Poetry</h3>
                  <Accordion type="single" collapsible className="space-y-4">
                    {/* Dust of Snow */}
                    <AccordionItem value="poem-1" className="border rounded-lg px-4 bg-card">
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-start gap-3 text-left">
                          <Badge className="mt-1 bg-primary text-primary-foreground">Poem</Badge>
                          <div>
                            <h3 className="font-semibold text-lg">Dust of Snow</h3>
                            <p className="text-sm text-muted-foreground">by Robert Frost</p>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pt-4 space-y-4">
                        <div className="space-y-4 pl-2">
                          <div>
                            <h4 className="font-semibold mb-2">The Poem:</h4>
                            <div className="bg-muted p-4 rounded-lg text-sm italic leading-relaxed">
                              <p>The way a crow</p>
                              <p>Shook down on me</p>
                              <p>The dust of snow</p>
                              <p>From a hemlock tree</p>
                              <br />
                              <p>Has given my heart</p>
                              <p>A change of mood</p>
                              <p>And saved some part</p>
                              <p>Of a day I had rued.</p>
                            </div>
                          </div>

                          <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                            <h4 className="font-semibold">Meaning & Message:</h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              A simple moment - snow falling from a tree because of a crow - changes the poet's sad mood
                              to a happy one. Small things in nature can bring joy and change our perspective.
                            </p>
                            <p className="text-sm font-semibold">
                              Message: Find happiness in small moments. Nature can heal us.
                            </p>
                          </div>

                          <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                            <h4 className="font-semibold mb-2">Exam Tip:</h4>
                            <p className="text-sm text-muted-foreground leading-relaxed">
                              Very short poem - memorize it! Know the meaning of "rued" (regretted). Understand the
                              contrast between negative symbols (crow, hemlock, dust) and positive message.
                            </p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    {/* More Poems */}
                    <Card className="bg-muted/50">
                      <CardContent className="pt-6">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>Fire and Ice - Robert Frost</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>A Tiger in the Zoo - Leslie Norris</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>How to Tell Wild Animals - Carolyn Wells</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>The Ball Poem - John Berryman</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>Amanda - Robin Klein</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>Animals - Walt Whitman</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>The Trees - Adrienne Rich</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Poem</Badge>
                            <span>Fog - Carl Sandburg</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Accordion>
                </div>
              </div>
            </TabsContent>

            {/* Grammar Tab */}
            <TabsContent value="grammar">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Grammar Rules Made Simple</h2>
                <p className="text-muted-foreground">Master the building blocks of English language</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Tenses */}
                <AccordionItem value="gram-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-primary text-primary-foreground">Topic</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Tenses</h3>
                        <p className="text-sm text-muted-foreground">Past, Present, Future forms</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2">What are Tenses?</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Tenses tell us WHEN an action happens - in the past, present, or future.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Present Tense:</h4>
                          <ul className="space-y-1 text-sm">
                            <li>
                              <strong>Simple Present:</strong> I eat / He eats (daily actions)
                            </li>
                            <li>
                              <strong>Present Continuous:</strong> I am eating (happening now)
                            </li>
                            <li>
                              <strong>Present Perfect:</strong> I have eaten (completed recently)
                            </li>
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Past Tense:</h4>
                          <ul className="space-y-1 text-sm">
                            <li>
                              <strong>Simple Past:</strong> I ate (completed action)
                            </li>
                            <li>
                              <strong>Past Continuous:</strong> I was eating (was happening)
                            </li>
                            <li>
                              <strong>Past Perfect:</strong> I had eaten (completed before another past action)
                            </li>
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Future Tense:</h4>
                          <ul className="space-y-1 text-sm">
                            <li>
                              <strong>Simple Future:</strong> I will eat (will happen)
                            </li>
                            <li>
                              <strong>Future Continuous:</strong> I will be eating (will be happening)
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Quick Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Look for time words: yesterday (past), now/today (present), tomorrow (future). Practice by
                          writing 5 sentences in each tense about your daily routine.
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Active Passive Voice */}
                <AccordionItem value="gram-2" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-primary text-primary-foreground">Topic</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Active and Passive Voice</h3>
                        <p className="text-sm text-muted-foreground">Changing sentence structure</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <div>
                          <h4 className="font-semibold mb-2">Active Voice:</h4>
                          <p className="text-sm text-muted-foreground">Subject does the action</p>
                          <p className="text-sm font-mono mt-1">Example: Ram writes a letter.</p>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Passive Voice:</h4>
                          <p className="text-sm text-muted-foreground">Action is done to the subject</p>
                          <p className="text-sm font-mono mt-1">Example: A letter is written by Ram.</p>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">How to Convert:</h4>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Step 1:</strong> Find the object in active sentence → It becomes subject in passive
                          </p>
                          <p>
                            <strong>Step 2:</strong> Use correct form of "be" + past participle of verb
                          </p>
                          <p>
                            <strong>Step 3:</strong> Add "by" + original subject (optional)
                          </p>
                        </div>
                      </div>

                      <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Always comes in exams! Remember: Object becomes subject. Learn past participles of common
                          verbs (write-written, do-done, see-seen).
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Grammar Topics */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <h4 className="font-semibold mb-3">Other Important Topics:</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Subject-Verb Agreement (He goes / They go)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Modals (can, could, should, must, may, might)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Reported Speech (Direct to Indirect speech)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Determiners (a, an, the, some, any, much, many)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Prepositions (in, on, at, by, with, for)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                        <span>Conjunctions (and, but, or, because, although)</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Writing Tab */}
            <TabsContent value="writing">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Writing Skills</h2>
                <p className="text-muted-foreground">Learn to write letters, essays, and stories effectively</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Letter Writing */}
                <AccordionItem value="write-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Format</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Letter Writing</h3>
                        <p className="text-sm text-muted-foreground">Formal and Informal letters</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <div>
                          <h4 className="font-semibold mb-2">Formal Letter (Official):</h4>
                          <div className="text-sm space-y-1 font-mono">
                            <p>1. Sender's address (top right)</p>
                            <p>2. Date</p>
                            <p>3. Receiver's address (left side)</p>
                            <p>4. Subject line</p>
                            <p>5. Salutation (Sir/Madam)</p>
                            <p>6. Body (3 paragraphs)</p>
                            <p>7. Closing (Yours faithfully/sincerely)</p>
                            <p>8. Signature & Name</p>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            Use for: Complaints, applications, requests to authorities
                          </p>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Informal Letter (Personal):</h4>
                          <div className="text-sm space-y-1 font-mono">
                            <p>1. Sender's address</p>
                            <p>2. Date</p>
                            <p>3. Salutation (Dear friend/name)</p>
                            <p>4. Body (friendly tone)</p>
                            <p>5. Closing (Yours lovingly/affectionately)</p>
                            <p>6. Name</p>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            Use for: Friends, family, personal messages
                          </p>
                        </div>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2 text-accent-foreground">Writing Tips:</h4>
                        <ul className="space-y-1 text-sm text-muted-foreground">
                          <li>• Use proper format - marks are given for format</li>
                          <li>• Keep it simple and clear</li>
                          <li>• Divide into 3 paragraphs: Introduction, Main content, Conclusion</li>
                          <li>• Check spelling and grammar before submitting</li>
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Article Writing */}
                <AccordionItem value="write-2" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Format</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Article Writing</h3>
                        <p className="text-sm text-muted-foreground">For newspaper or magazine</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold mb-2">Article Structure:</h4>
                        <ul className="space-y-2 text-sm">
                          <li>
                            <strong>1. Catchy Title:</strong> Grab attention with interesting headline
                          </li>
                          <li>
                            <strong>2. By Line:</strong> "By [Your Name]"
                          </li>
                          <li>
                            <strong>3. Introduction:</strong> What is the topic? Why is it important?
                          </li>
                          <li>
                            <strong>4. Body (2-3 paragraphs):</strong> Main points, examples, facts
                          </li>
                          <li>
                            <strong>5. Conclusion:</strong> Summary or call to action
                          </li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Common Topics:</h4>
                        <div className="grid sm:grid-cols-2 gap-2 text-sm">
                          <p>• Environmental issues</p>
                          <p>• Social media effects</p>
                          <p>• Education system</p>
                          <p>• Health and fitness</p>
                          <p>• Technology</p>
                          <p>• Women empowerment</p>
                        </div>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2 text-accent-foreground">Pro Tips:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Use facts and statistics if possible. Keep language formal but engaging. Word limit: 150-200
                          words usually. Practice writing on current topics.
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Writing Formats */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <h4 className="font-semibold mb-3">Other Writing Formats:</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                        <span>
                          <strong>Story Writing:</strong> Title, Beginning, Middle, End, Moral
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                        <span>
                          <strong>Notice Writing:</strong> For announcements in school/society
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                        <span>
                          <strong>Message Writing:</strong> Short messages (50 words)
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                        <span>
                          <strong>Diary Entry:</strong> Personal thoughts in first person
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                        <span>
                          <strong>Report Writing:</strong> Factual account of events
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>
          </Tabs>
        </div>

        {/* Quick Links */}
        <div className="max-w-4xl mx-auto mt-12 grid sm:grid-cols-2 gap-4">
          <Card className="bg-chart-4 text-background">
            <CardHeader>
              <CardTitle>Practice Questions</CardTitle>
              <CardDescription className="text-background/80">
                Literature, Grammar, and Writing practice
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/practice/english">Start Practice</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle>Quick Revision</CardTitle>
              <CardDescription className="text-primary-foreground/80">
                Summaries, grammar rules, formats
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/revision/english">View Revision Notes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
