import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen, Calculator, CheckCircle2 } from "lucide-react"

export default function MathematicsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                  <Calculator className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Mathematics</h1>
                  <p className="text-xs text-muted-foreground">Class 10 NCERT</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Welcome to Mathematics</CardTitle>
              <CardDescription className="text-base">
                Mathematics helps you solve real problems using numbers and logic. Don't worry - we'll explain
                everything in simple steps.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                <p className="font-semibold text-foreground">Why is Mathematics important?</p>
                <ul className="list-disc list-inside space-y-2 ml-2">
                  <li>Helps in daily life - calculating money, measuring things, understanding time</li>
                  <li>Builds logical thinking and problem-solving skills</li>
                  <li>Required for many careers like engineering, business, science</li>
                  <li>Trains your brain to think clearly and make smart decisions</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chapters List */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">All Chapters</h2>
            <p className="text-muted-foreground">Click on any chapter to learn step-by-step</p>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {/* Chapter 1 */}
            <AccordionItem value="chapter-1" className="border rounded-lg px-4 bg-card">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-start gap-3 text-left">
                  <Badge className="mt-1">Ch 1</Badge>
                  <div>
                    <h3 className="font-semibold text-lg">Real Numbers</h3>
                    <p className="text-sm text-muted-foreground">Euclid's Division, HCF, LCM, Prime numbers</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-4">
                <div className="space-y-4 pl-2">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      What are Real Numbers?
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Real numbers are all numbers you can think of - positive, negative, fractions, decimals. Example:
                      5, -3, 2.5, 0, √2 are all real numbers.
                    </p>
                  </div>

                  <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold">Key Topics:</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Euclid's Division Algorithm:</strong> A method to find HCF of two numbers
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>HCF & LCM:</strong> Highest Common Factor and Lowest Common Multiple
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Decimal Expansion:</strong> Terminating and Non-terminating decimals
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Example:</h4>
                    <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                      <p className="font-medium">Find HCF of 18 and 24</p>
                      <p className="text-muted-foreground">
                        <strong>Step 1:</strong> Write factors of both numbers
                        <br />
                        18 = 1, 2, 3, 6, 9, 18
                        <br />
                        24 = 1, 2, 3, 4, 6, 8, 12, 24
                      </p>
                      <p className="text-muted-foreground">
                        <strong>Step 2:</strong> Find common factors = 1, 2, 3, 6
                      </p>
                      <p className="text-primary font-semibold">
                        <strong>Answer:</strong> HCF = 6 (highest common factor)
                      </p>
                    </div>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      This chapter has many formula-based questions. Practice finding HCF using both methods - listing
                      factors and Euclid's algorithm. Remember: HCF × LCM = Product of two numbers.
                    </p>
                  </div>

                  <Button className="w-full sm:w-auto" asChild>
                    <Link href="/mathematics/chapter-1">View Full Chapter & Practice Questions</Link>
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Chapter 2 */}
            <AccordionItem value="chapter-2" className="border rounded-lg px-4 bg-card">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-start gap-3 text-left">
                  <Badge className="mt-1">Ch 2</Badge>
                  <div>
                    <h3 className="font-semibold text-lg">Polynomials</h3>
                    <p className="text-sm text-muted-foreground">Linear, Quadratic, Cubic polynomials</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-4">
                <div className="space-y-4 pl-2">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      What are Polynomials?
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Polynomials are expressions with variables and powers. Example: 2x + 3, x² + 5x + 6. Think of them
                      as math sentences with x (unknown) that we need to solve.
                    </p>
                  </div>

                  <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold">Key Topics:</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Types of Polynomials:</strong> Linear (x), Quadratic (x²), Cubic (x³)
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Zeroes of Polynomial:</strong> Values of x where polynomial becomes zero
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Division Algorithm:</strong> Dividing one polynomial by another
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Example:</h4>
                    <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                      <p className="font-medium">Find zeroes of polynomial x² - 5x + 6</p>
                      <p className="text-muted-foreground">
                        <strong>Step 1:</strong> Factorize: x² - 5x + 6 = (x - 2)(x - 3)
                      </p>
                      <p className="text-muted-foreground">
                        <strong>Step 2:</strong> Set each factor to zero
                        <br />x - 2 = 0, so x = 2<br />x - 3 = 0, so x = 3
                      </p>
                      <p className="text-primary font-semibold">
                        <strong>Answer:</strong> Zeroes are 2 and 3
                      </p>
                    </div>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Factorization questions are very common. Practice finding zeroes and verifying using sum and
                      product relationships. Don't forget to check your answer by substituting back.
                    </p>
                  </div>

                  <Button className="w-full sm:w-auto" asChild>
                    <Link href="/mathematics/chapter-2">View Full Chapter & Practice Questions</Link>
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Chapter 3 */}
            <AccordionItem value="chapter-3" className="border rounded-lg px-4 bg-card">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-start gap-3 text-left">
                  <Badge className="mt-1">Ch 3</Badge>
                  <div>
                    <h3 className="font-semibold text-lg">Pair of Linear Equations in Two Variables</h3>
                    <p className="text-sm text-muted-foreground">Graphical & Algebraic methods</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-4">
                <div className="space-y-4 pl-2">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      What are Linear Equations?
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      These are equations with two unknowns (x and y). Example: 2x + 3y = 12. We need to find values of
                      both x and y that satisfy the equation.
                    </p>
                  </div>

                  <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold">Key Topics:</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Graphical Method:</strong> Drawing lines and finding intersection point
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Substitution Method:</strong> Find one variable, then substitute
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Elimination Method:</strong> Add or subtract equations to eliminate a variable
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Example:</h4>
                    <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                      <p className="font-medium">Solve: x + y = 7 and x - y = 3</p>
                      <p className="text-muted-foreground">
                        <strong>Using Elimination:</strong>
                        <br />
                        Add both equations: (x + y) + (x - y) = 7 + 3
                        <br />
                        2x = 10, so x = 5
                      </p>
                      <p className="text-muted-foreground">
                        Put x = 5 in first equation: 5 + y = 7
                        <br />
                        So y = 2
                      </p>
                      <p className="text-primary font-semibold">
                        <strong>Answer:</strong> x = 5, y = 2
                      </p>
                    </div>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Word problems are common in exams. Read carefully and convert sentences into equations. Practice
                      all three methods - you may need to use different ones for different questions.
                    </p>
                  </div>

                  <Button className="w-full sm:w-auto" asChild>
                    <Link href="/mathematics/chapter-3">View Full Chapter & Practice Questions</Link>
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Chapter 4 */}
            <AccordionItem value="chapter-4" className="border rounded-lg px-4 bg-card">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-start gap-3 text-left">
                  <Badge className="mt-1">Ch 4</Badge>
                  <div>
                    <h3 className="font-semibold text-lg">Quadratic Equations</h3>
                    <p className="text-sm text-muted-foreground">Solving equations with x²</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-4">
                <div className="space-y-4 pl-2">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      What are Quadratic Equations?
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Equations where highest power of x is 2. Standard form: ax² + bx + c = 0. Example: x² - 5x + 6 =
                      0. These have two solutions.
                    </p>
                  </div>

                  <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold">Important Formulas:</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Quadratic Formula:</strong> x = [-b ± √(b² - 4ac)] / 2a
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Discriminant:</strong> D = b² - 4ac (tells us about nature of roots)
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Sum of roots:</strong> α + β = -b/a
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Product of roots:</strong> αβ = c/a
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      This is a HIGH SCORING chapter. Memorize the quadratic formula and discriminant. Practice word
                      problems about age, speed, and area - they always come in exams.
                    </p>
                  </div>

                  <Button className="w-full sm:w-auto" asChild>
                    <Link href="/mathematics/chapter-4">View Full Chapter & Practice Questions</Link>
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Chapter 5 */}
            <AccordionItem value="chapter-5" className="border rounded-lg px-4 bg-card">
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-start gap-3 text-left">
                  <Badge className="mt-1">Ch 5</Badge>
                  <div>
                    <h3 className="font-semibold text-lg">Arithmetic Progressions (AP)</h3>
                    <p className="text-sm text-muted-foreground">Number sequences with patterns</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 space-y-4">
                <div className="space-y-4 pl-2">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      What is AP?
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      A sequence where each number is obtained by adding a fixed number to the previous one. Example: 2,
                      5, 8, 11, 14... (adding 3 each time)
                    </p>
                  </div>

                  <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold">Important Formulas:</h4>
                    <ul className="space-y-2 text-sm font-mono">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>nth term:</strong> aₙ = a + (n-1)d
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Sum of n terms:</strong> Sₙ = n/2 [2a + (n-1)d]
                        </div>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <div>
                          <strong>Alternative sum:</strong> Sₙ = n/2 (first + last term)
                        </div>
                      </li>
                    </ul>
                    <p className="text-xs text-muted-foreground mt-2">
                      Where: a = first term, d = common difference, n = number of terms
                    </p>
                  </div>

                  <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Easy chapter to score full marks! Just memorize the 2-3 formulas. Practice finding d (common
                      difference) first - it's the key to solving most problems.
                    </p>
                  </div>

                  <Button className="w-full sm:w-auto" asChild>
                    <Link href="/mathematics/chapter-5">View Full Chapter & Practice Questions</Link>
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>

            {/* Remaining Chapters - Collapsed View */}
            <Card className="bg-muted/50">
              <CardHeader>
                <CardTitle className="text-lg">More Chapters</CardTitle>
                <CardDescription>10 more chapters covering important topics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 6</Badge>
                    <span>Triangles - Similarity, Congruence, Pythagoras Theorem</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 7</Badge>
                    <span>Coordinate Geometry - Distance, Section Formula</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 8</Badge>
                    <span>Introduction to Trigonometry - Sin, Cos, Tan</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 9</Badge>
                    <span>Applications of Trigonometry - Heights & Distances</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 10</Badge>
                    <span>Circles - Tangents, Properties</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 11</Badge>
                    <span>Constructions - Geometric Drawings</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 12</Badge>
                    <span>Areas Related to Circles</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 13</Badge>
                    <span>Surface Areas and Volumes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 14</Badge>
                    <span>Statistics - Mean, Median, Mode</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Ch 15</Badge>
                    <span>Probability - Chance & Likelihood</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-4">
                  Full detailed chapters with examples coming soon! For now, use NCERT textbook alongside this platform.
                </p>
              </CardContent>
            </Card>
          </Accordion>
        </div>

        {/* Quick Links */}
        <div className="max-w-4xl mx-auto mt-12 grid sm:grid-cols-2 gap-4">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle>Practice Questions</CardTitle>
              <CardDescription className="text-primary-foreground/80">
                Test your understanding with MCQs and problems
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/practice/mathematics">Start Practice</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-accent text-accent-foreground">
            <CardHeader>
              <CardTitle>Quick Revision</CardTitle>
              <CardDescription className="text-accent-foreground/80">
                All formulas and important points in one place
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/revision/mathematics">View Revision Notes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
