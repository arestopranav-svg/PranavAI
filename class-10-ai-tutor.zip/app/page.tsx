import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Calculator, Atom, Globe, Languages, FileText, Lightbulb, Target } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Class 10 AI Teacher</h1>
                <p className="text-xs text-muted-foreground">Learn Simply, Score Better</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 md:py-20 bg-gradient-to-b from-secondary/30 to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold text-balance mb-4 text-foreground">
              Your Friendly AI Teacher for Class 10
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground text-balance mb-8 leading-relaxed">
              Learn all subjects in simple language. Step-by-step explanations, real-life examples, and exam tips - all
              in one place.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-base" asChild>
                <Link href="#subjects">Start Learning Now</Link>
              </Button>
              <Button size="lg" variant="outline" className="text-base bg-transparent" asChild>
                <Link href="#features">How It Works</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Subjects Dashboard */}
      <section id="subjects" className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Choose Your Subject</h3>
            <p className="text-lg text-muted-foreground text-balance max-w-2xl mx-auto">
              Click on any subject to start learning. Each subject has easy chapters, examples, and practice questions.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {/* Mathematics */}
            <Link href="/mathematics" className="group">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary">
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all">
                    <Calculator className="w-7 h-7 text-primary group-hover:text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">Mathematics</CardTitle>
                  <CardDescription className="text-base">Numbers, Algebra, Geometry & more</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• 15 Chapters</p>
                    <p>• Formulas & Examples</p>
                    <p>• Practice Problems</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Science */}
            <Link href="/science" className="group">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary">
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent group-hover:scale-110 transition-all">
                    <Atom className="w-7 h-7 text-accent group-hover:text-accent-foreground" />
                  </div>
                  <CardTitle className="text-2xl">Science</CardTitle>
                  <CardDescription className="text-base">Physics, Chemistry & Biology</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• 16 Chapters</p>
                    <p>• Concepts & Diagrams</p>
                    <p>• Real-life Examples</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Social Science */}
            <Link href="/social-science" className="group">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary">
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 rounded-xl bg-chart-3/10 flex items-center justify-center mb-4 group-hover:bg-chart-3 group-hover:scale-110 transition-all">
                    <Globe className="w-7 h-7 text-chart-3 group-hover:text-background" />
                  </div>
                  <CardTitle className="text-2xl">Social Science</CardTitle>
                  <CardDescription className="text-base">History, Geography, Civics, Economics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• 20 Chapters</p>
                    <p>• Easy Summaries</p>
                    <p>• Important Dates</p>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* English */}
            <Link href="/english" className="group">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary">
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 rounded-xl bg-chart-4/10 flex items-center justify-center mb-4 group-hover:bg-chart-4 group-hover:scale-110 transition-all">
                    <Languages className="w-7 h-7 text-chart-4 group-hover:text-background" />
                  </div>
                  <CardTitle className="text-2xl">English</CardTitle>
                  <CardDescription className="text-base">Grammar, Literature & Writing</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• Prose & Poetry</p>
                    <p>• Grammar Rules</p>
                    <p>• Writing Tips</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 md:py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Why Students Love Us</h3>
            <p className="text-lg text-muted-foreground text-balance max-w-2xl mx-auto">
              We make learning easy and fun. No boring lectures, just simple explanations that make sense.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Simple Language</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  No difficult words. We explain everything like a friendly teacher talking to you.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-3">
                  <Lightbulb className="w-6 h-6 text-accent" />
                </div>
                <CardTitle className="text-lg">Real Examples</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Learn with examples from daily life. Makes concepts easy to remember.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mx-auto mb-3">
                  <BookOpen className="w-6 h-6 text-chart-3" />
                </div>
                <CardTitle className="text-lg">Step-by-Step</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Every chapter broken into small, easy steps. Learn at your own pace.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-chart-4/10 flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-chart-4" />
                </div>
                <CardTitle className="text-lg">Exam Ready</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Practice questions, exam tips, and quick revision notes for better marks.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4">
          <Card className="bg-primary text-primary-foreground max-w-3xl mx-auto">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-3xl md:text-4xl mb-3">Ready to Start Learning?</CardTitle>
              <CardDescription className="text-primary-foreground/90 text-lg">
                Choose any subject above and begin your journey. No login needed - just start learning!
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button size="lg" variant="secondary" className="text-base" asChild>
                <Link href="#subjects">Browse All Subjects</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 bg-card">
        <div className="container mx-auto px-4">
          <div className="text-center text-sm text-muted-foreground">
            <p>Class 10 AI Teacher - Making learning simple and accessible for everyone</p>
            <p className="mt-2">All subjects based on NCERT Class 10 syllabus</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
