"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calculator, CheckCircle2, XCircle, RotateCcw } from "lucide-react"

// Sample questions
const questions = [
  {
    id: 1,
    question: "What is the HCF of 18 and 24?",
    options: ["4", "6", "8", "12"],
    correct: 1,
    explanation:
      "Factors of 18: 1, 2, 3, 6, 9, 18. Factors of 24: 1, 2, 3, 4, 6, 8, 12, 24. Highest common factor is 6.",
    chapter: "Real Numbers",
  },
  {
    id: 2,
    question: "If x + y = 7 and x - y = 3, what is the value of x?",
    options: ["3", "4", "5", "6"],
    correct: 2,
    explanation: "Add both equations: (x + y) + (x - y) = 7 + 3, so 2x = 10, therefore x = 5.",
    chapter: "Linear Equations",
  },
  {
    id: 3,
    question: "What is the formula for the area of a circle?",
    options: ["2πr", "πr²", "πr³", "2πr²"],
    correct: 1,
    explanation: "The area of a circle is calculated using the formula A = πr², where r is the radius.",
    chapter: "Geometry",
  },
  {
    id: 4,
    question: "The value of sin 90° is:",
    options: ["0", "1", "1/2", "√3/2"],
    correct: 1,
    explanation: "sin 90° = 1. This is a standard trigonometric value that should be memorized.",
    chapter: "Trigonometry",
  },
  {
    id: 5,
    question: "If the discriminant of a quadratic equation is negative, the roots are:",
    options: ["Real and equal", "Real and unequal", "Imaginary", "Zero"],
    correct: 2,
    explanation: "When D = b² - 4ac < 0, the quadratic equation has imaginary (or complex) roots, not real roots.",
    chapter: "Quadratic Equations",
  },
  {
    id: 6,
    question: "The sum of first n natural numbers is given by:",
    options: ["n(n+1)", "n(n+1)/2", "n²", "n(n-1)/2"],
    correct: 1,
    explanation: "The formula for sum of first n natural numbers is n(n+1)/2. For example, 1+2+3+4+5 = 5(6)/2 = 15.",
    chapter: "Arithmetic Progression",
  },
  {
    id: 7,
    question: "What is the value of tan 45°?",
    options: ["0", "1", "√3", "1/√3"],
    correct: 1,
    explanation: "tan 45° = 1. At 45 degrees, the opposite and adjacent sides of a right triangle are equal.",
    chapter: "Trigonometry",
  },
  {
    id: 8,
    question: "The zeroes of polynomial x² - 5x + 6 are:",
    options: ["2 and 3", "1 and 6", "-2 and -3", "2 and -3"],
    correct: 0,
    explanation: "Factorize: x² - 5x + 6 = (x-2)(x-3). Setting each factor to zero gives x = 2 and x = 3.",
    chapter: "Polynomials",
  },
]

export default function MathematicsPracticePage() {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({})
  const [showResults, setShowResults] = useState(false)

  const handleAnswerSelect = (questionId: number, answerIndex: number) => {
    if (!showResults) {
      setSelectedAnswers((prev) => ({ ...prev, [questionId]: answerIndex }))
    }
  }

  const handleSubmit = () => {
    setShowResults(true)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleReset = () => {
    setSelectedAnswers({})
    setShowResults(false)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const calculateScore = () => {
    let correct = 0
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correct) correct++
    })
    return correct
  }

  const score = showResults ? calculateScore() : 0
  const percentage = showResults ? Math.round((score / questions.length) * 100) : 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/practice">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                  <Calculator className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Mathematics Practice</h1>
                  <p className="text-xs text-muted-foreground">{questions.length} Questions</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Results Card */}
        {showResults && (
          <div className="max-w-3xl mx-auto mb-8">
            <Card className="bg-primary/5 border-primary">
              <CardHeader>
                <CardTitle className="text-2xl">Your Score</CardTitle>
                <CardDescription>Here's how you performed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-4xl font-bold text-primary">
                      {score} / {questions.length}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Questions Correct</p>
                  </div>
                  <div className="text-right">
                    <div className="text-4xl font-bold text-accent">{percentage}%</div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {percentage >= 75 ? "Excellent!" : percentage >= 50 ? "Good Job!" : "Keep Practicing!"}
                    </p>
                  </div>
                </div>
                <Button className="w-full mt-6 bg-transparent" onClick={handleReset} variant="outline">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Questions */}
        <div className="max-w-3xl mx-auto space-y-6">
          {questions.map((question, qIndex) => {
            const isAnswered = selectedAnswers[question.id] !== undefined
            const isCorrect = isAnswered && selectedAnswers[question.id] === question.correct
            const isWrong = isAnswered && showResults && selectedAnswers[question.id] !== question.correct

            return (
              <Card
                key={question.id}
                className={isWrong ? "border-destructive" : isCorrect && showResults ? "border-primary" : ""}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">Q{qIndex + 1}</Badge>
                        <Badge variant="secondary" className="text-xs">
                          {question.chapter}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg font-semibold leading-relaxed">{question.question}</CardTitle>
                    </div>
                    {showResults && (
                      <div>
                        {isCorrect ? (
                          <CheckCircle2 className="w-6 h-6 text-primary" />
                        ) : (
                          <XCircle className="w-6 h-6 text-destructive" />
                        )}
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <RadioGroup
                    value={selectedAnswers[question.id]?.toString()}
                    onValueChange={(value) => handleAnswerSelect(question.id, Number.parseInt(value))}
                  >
                    {question.options.map((option, optionIndex) => {
                      const isThisCorrect = optionIndex === question.correct
                      const isSelected = selectedAnswers[question.id] === optionIndex

                      return (
                        <div
                          key={optionIndex}
                          className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                            showResults && isThisCorrect
                              ? "border-primary bg-primary/5"
                              : showResults && isSelected && !isThisCorrect
                                ? "border-destructive bg-destructive/5"
                                : isSelected
                                  ? "border-primary bg-primary/5"
                                  : "border-border hover:border-primary/50"
                          }`}
                        >
                          <RadioGroupItem
                            value={optionIndex.toString()}
                            id={`q${question.id}-${optionIndex}`}
                            disabled={showResults}
                          />
                          <Label
                            htmlFor={`q${question.id}-${optionIndex}`}
                            className="flex-1 cursor-pointer text-sm leading-relaxed"
                          >
                            {option}
                            {showResults && isThisCorrect && (
                              <span className="ml-2 text-primary font-semibold text-xs">(Correct)</span>
                            )}
                          </Label>
                        </div>
                      )
                    })}
                  </RadioGroup>

                  {showResults && (
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <p className="text-sm font-semibold mb-1">Explanation:</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">{question.explanation}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Submit Button */}
        {!showResults && (
          <div className="max-w-3xl mx-auto mt-8">
            <Button
              className="w-full"
              size="lg"
              onClick={handleSubmit}
              disabled={Object.keys(selectedAnswers).length !== questions.length}
            >
              {Object.keys(selectedAnswers).length === questions.length
                ? "Submit Answers"
                : `Answer All Questions (${Object.keys(selectedAnswers).length}/${questions.length})`}
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
