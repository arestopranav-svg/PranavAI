import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Calculator, Atom, Globe, Target, Trophy, Clock } from "lucide-react"

export default function PracticePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                  <Target className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Practice Questions</h1>
                  <p className="text-xs text-muted-foreground">Test your knowledge</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Practice Makes Perfect</CardTitle>
              <CardDescription className="text-base">
                Choose a subject and start practicing. MCQs and short questions to test your understanding.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4 text-center">
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
                    <Trophy className="w-6 h-6 text-primary" />
                  </div>
                  <p className="text-sm font-semibold">Check Answers</p>
                  <p className="text-xs text-muted-foreground">Instant feedback on your responses</p>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto">
                    <Clock className="w-6 h-6 text-accent" />
                  </div>
                  <p className="text-sm font-semibold">Learn from Mistakes</p>
                  <p className="text-xs text-muted-foreground">See correct answers with explanations</p>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mx-auto">
                    <Target className="w-6 h-6 text-chart-3" />
                  </div>
                  <p className="text-sm font-semibold">Track Progress</p>
                  <p className="text-xs text-muted-foreground">See how many you got right</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Selection */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">Choose Subject to Practice</h2>
            <p className="text-muted-foreground">Click any subject to start solving questions</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {/* Mathematics */}
            <Link href="/practice/mathematics">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all flex-shrink-0">
                      <Calculator className="w-7 h-7 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Mathematics</CardTitle>
                      <CardDescription>Formulas, problems & MCQs</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center justify-between">
                      <span>Total Questions:</span>
                      <span className="font-semibold text-foreground">50+</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Difficulty:</span>
                      <span className="font-semibold text-foreground">Easy to Hard</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Type:</span>
                      <span className="font-semibold text-foreground">MCQ + Numerical</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Science */}
            <Link href="/practice/science">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-accent group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all flex-shrink-0">
                      <Atom className="w-7 h-7 text-accent group-hover:text-accent-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Science</CardTitle>
                      <CardDescription>Physics, Chemistry, Biology</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center justify-between">
                      <span>Total Questions:</span>
                      <span className="font-semibold text-foreground">60+</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Difficulty:</span>
                      <span className="font-semibold text-foreground">Easy to Hard</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Type:</span>
                      <span className="font-semibold text-foreground">MCQ + Short Answers</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* Social Science */}
            <Link href="/practice/social-science">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-chart-3 group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-chart-3/10 flex items-center justify-center group-hover:bg-chart-3 group-hover:scale-110 transition-all flex-shrink-0">
                      <Globe className="w-7 h-7 text-chart-3 group-hover:text-background" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Social Science</CardTitle>
                      <CardDescription>History, Geography, Civics, Economics</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center justify-between">
                      <span>Total Questions:</span>
                      <span className="font-semibold text-foreground">70+</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Difficulty:</span>
                      <span className="font-semibold text-foreground">Easy to Medium</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Type:</span>
                      <span className="font-semibold text-foreground">MCQ + Short Answers</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>

        {/* Tips Section */}
        <div className="max-w-4xl mx-auto mt-12">
          <Card className="bg-secondary/30">
            <CardHeader>
              <CardTitle>Tips for Practice</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground leading-relaxed">
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold flex-shrink-0">1.</span>
                  <span>
                    <strong>Read questions carefully</strong> - Don't rush, understand what is being asked
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold flex-shrink-0">2.</span>
                  <span>
                    <strong>Try before checking</strong> - Attempt all questions first, then check answers
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold flex-shrink-0">3.</span>
                  <span>
                    <strong>Learn from mistakes</strong> - If you get something wrong, understand why
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary font-bold flex-shrink-0">4.</span>
                  <span>
                    <strong>Repeat difficult ones</strong> - Come back and practice questions you found hard
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
