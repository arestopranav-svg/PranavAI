import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calculator, Star, AlertTriangle } from "lucide-react"

export default function MathematicsRevisionPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/revision">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                  <Calculator className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Mathematics Revision</h1>
                  <p className="text-xs text-muted-foreground">All formulas & key points</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Important Notice */}
          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                <CardTitle>Quick Revision Guide</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed">
              <p>
                This page contains all the important formulas, concepts, and tips for Class 10 Mathematics. Go through
                each chapter carefully before your exam.
              </p>
            </CardContent>
          </Card>

          {/* Chapter-wise Formulas */}
          <div>
            <h2 className="text-2xl font-bold mb-4">Chapter-wise Formulas & Key Points</h2>

            <Accordion type="single" collapsible className="space-y-4">
              {/* Real Numbers */}
              <AccordionItem value="ch-1" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 1</Badge>
                    <span className="font-semibold">Real Numbers</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Key Formulas:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>HCF × LCM = Product of two numbers</p>
                        <p>Euclid's Division Lemma: a = bq + r (0 ≤ r {"<"} b)</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Important Points:</h4>
                      <ul className="text-sm space-y-1 text-muted-foreground list-disc list-inside">
                        <li>Every rational number has either terminating or repeating decimal</li>
                        <li>Irrational numbers have non-terminating, non-repeating decimals</li>
                        <li>√2, √3, π are irrational numbers</li>
                      </ul>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Polynomials */}
              <AccordionItem value="ch-2" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 2</Badge>
                    <span className="font-semibold">Polynomials</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Key Formulas:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>For quadratic polynomial ax² + bx + c:</p>
                        <p>Sum of zeroes (α + β) = -b/a</p>
                        <p>Product of zeroes (αβ) = c/a</p>
                        <p>
                          Division Algorithm: p(x) = g(x) × q(x) + r(x) <br />
                          where degree of r(x) {"<"} degree of g(x)
                        </p>
                      </div>
                    </div>

                    <div className="bg-primary/10 border border-primary/20 p-3 rounded-lg">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-muted-foreground">
                          <strong>Common Mistake:</strong> Don't forget the sign convention. Sum = -b/a (negative b)
                        </p>
                      </div>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Quadratic Equations */}
              <AccordionItem value="ch-4" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 4</Badge>
                    <span className="font-semibold">Quadratic Equations</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Most Important Formulas:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>Standard form: ax² + bx + c = 0</p>
                        <p>Quadratic formula: x = [-b ± √(b² - 4ac)] / 2a</p>
                        <p>Discriminant: D = b² - 4ac</p>
                        <div className="mt-3 space-y-1 text-xs">
                          <p>If D {">"} 0: Real and unequal roots</p>
                          <p>If D = 0: Real and equal roots</p>
                          <p>If D {"<"} 0: No real roots (imaginary)</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-accent/10 border border-accent/20 p-3 rounded-lg">
                      <p className="text-sm font-semibold mb-1">Exam Tip:</p>
                      <p className="text-sm text-muted-foreground">
                        This chapter has HIGH weightage. Always memorize the quadratic formula. Word problems on age,
                        speed, and time are common.
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* AP */}
              <AccordionItem value="ch-5" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 5</Badge>
                    <span className="font-semibold">Arithmetic Progressions</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">All Formulas You Need:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>nth term: aₙ = a + (n-1)d</p>
                        <p>Sum of n terms: Sₙ = n/2 [2a + (n-1)d]</p>
                        <p>OR: Sₙ = n/2 (first term + last term)</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          Where: a = first term, d = common difference, n = number of terms
                        </p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2 text-sm">Quick Memory Trick:</h4>
                      <p className="text-sm text-muted-foreground">
                        Finding d (common difference) is always your first step. Just subtract: d = 2nd term - 1st term
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Trigonometry */}
              <AccordionItem value="ch-8" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 8</Badge>
                    <span className="font-semibold">Introduction to Trigonometry</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Basic Ratios:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>sin θ = Opposite / Hypotenuse</p>
                        <p>cos θ = Adjacent / Hypotenuse</p>
                        <p>tan θ = Opposite / Adjacent</p>
                        <p className="mt-2">cosec θ = 1/sin θ</p>
                        <p>sec θ = 1/cos θ</p>
                        <p>cot θ = 1/tan θ</p>
                      </div>
                    </div>

                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Important Values (MUST MEMORIZE):</h4>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs border">
                          <thead>
                            <tr className="bg-muted">
                              <th className="border p-2">Angle</th>
                              <th className="border p-2">0°</th>
                              <th className="border p-2">30°</th>
                              <th className="border p-2">45°</th>
                              <th className="border p-2">60°</th>
                              <th className="border p-2">90°</th>
                            </tr>
                          </thead>
                          <tbody className="font-mono">
                            <tr>
                              <td className="border p-2 font-semibold">sin</td>
                              <td className="border p-2">0</td>
                              <td className="border p-2">1/2</td>
                              <td className="border p-2">1/√2</td>
                              <td className="border p-2">√3/2</td>
                              <td className="border p-2">1</td>
                            </tr>
                            <tr>
                              <td className="border p-2 font-semibold">cos</td>
                              <td className="border p-2">1</td>
                              <td className="border p-2">√3/2</td>
                              <td className="border p-2">1/√2</td>
                              <td className="border p-2">1/2</td>
                              <td className="border p-2">0</td>
                            </tr>
                            <tr>
                              <td className="border p-2 font-semibold">tan</td>
                              <td className="border p-2">0</td>
                              <td className="border p-2">1/√3</td>
                              <td className="border p-2">1</td>
                              <td className="border p-2">√3</td>
                              <td className="border p-2">∞</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Trigonometric Identities:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>sin²θ + cos²θ = 1</p>
                        <p>1 + tan²θ = sec²θ</p>
                        <p>1 + cot²θ = cosec²θ</p>
                      </div>
                    </div>

                    <div className="bg-primary/10 border border-primary/20 p-3 rounded-lg">
                      <p className="text-sm font-semibold mb-1">Memory Trick:</p>
                      <p className="text-sm text-muted-foreground">
                        For 0°, 30°, 45°, 60°, 90°: sin values are √0, √1, √2, √3, √4 all divided by 2. cos values are
                        reverse of sin!
                      </p>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Coordinate Geometry */}
              <AccordionItem value="ch-7" className="border rounded-lg px-4 bg-card">
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-start gap-3 text-left">
                    <Badge className="mt-1">Ch 7</Badge>
                    <span className="font-semibold">Coordinate Geometry</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pt-4 space-y-4">
                  <div className="space-y-3 pl-2">
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Essential Formulas:</h4>
                      <div className="space-y-2 text-sm font-mono">
                        <p>Distance Formula:</p>
                        <p className="ml-4">d = √[(x₂-x₁)² + (y₂-y₁)²]</p>
                        <p className="mt-2">Section Formula (Internal):</p>
                        <p className="ml-4">x = (m₁x₂ + m₂x₁)/(m₁+m₂)</p>
                        <p className="ml-4">y = (m₁y₂ + m₂y₁)/(m₁+m₂)</p>
                        <p className="mt-2">Mid-point Formula:</p>
                        <p className="ml-4">x = (x₁+x₂)/2, y = (y₁+y₂)/2</p>
                        <p className="mt-2">Area of Triangle:</p>
                        <p className="ml-4">A = ½|x₁(y₂-y₃) + x₂(y₃-y₁) + x₃(y₁-y₂)|</p>
                      </div>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          {/* General Tips */}
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardHeader>
              <CardTitle>Mathematics Exam Strategy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div>
                <h3 className="font-semibold mb-2">High Scoring Chapters:</h3>
                <ul className="space-y-1 text-muted-foreground list-disc list-inside">
                  <li>Quadratic Equations - Easy numericals, always practice</li>
                  <li>Arithmetic Progressions - Direct formula application</li>
                  <li>Coordinate Geometry - Straightforward calculations</li>
                  <li>Statistics - Mean, Median, Mode are scoring</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Time-Saving Tips:</h3>
                <ul className="space-y-1 text-muted-foreground list-disc list-inside">
                  <li>Always write "Given" and "To Find" in word problems</li>
                  <li>Show all steps - you get marks for method even if answer is wrong</li>
                  <li>Draw neat diagrams in geometry - use pencil and scale</li>
                  <li>Double-check calculations in last 10 minutes</li>
                  <li>If stuck, move to next question - don't waste time</li>
                </ul>
              </div>

              <div className="bg-destructive/10 border border-destructive/20 p-3 rounded-lg">
                <h3 className="font-semibold mb-2 text-destructive">Common Mistakes to Avoid:</h3>
                <ul className="space-y-1 text-muted-foreground list-disc list-inside">
                  <li>Forgetting to write units in answers (cm, m, ₹, etc.)</li>
                  <li>Sign errors in formulas (negative signs)</li>
                  <li>Not simplifying final answer</li>
                  <li>Calculation mistakes - use rough work properly</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
