import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BookMarked, Calculator, Atom, Globe, Languages, Sparkles, Clock, Lightbulb } from "lucide-react"

export default function RevisionPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
                  <BookMarked className="w-6 h-6 text-accent-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Quick Revision</h1>
                  <p className="text-xs text-muted-foreground">Last minute preparation</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-accent/5 border-accent/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Revise Before Exams</CardTitle>
              <CardDescription className="text-base">
                All important formulas, concepts, and tips in one place for quick review before your exam.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4 text-center">
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto">
                    <Sparkles className="w-6 h-6 text-accent" />
                  </div>
                  <p className="text-sm font-semibold">Key Points Only</p>
                  <p className="text-xs text-muted-foreground">No long paragraphs, just important stuff</p>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <p className="text-sm font-semibold">Quick to Read</p>
                  <p className="text-xs text-muted-foreground">Perfect for last-minute revision</p>
                </div>
                <div className="space-y-2">
                  <div className="w-12 h-12 rounded-lg bg-chart-3/10 flex items-center justify-center mx-auto">
                    <Lightbulb className="w-6 h-6 text-chart-3" />
                  </div>
                  <p className="text-sm font-semibold">Exam Tips Included</p>
                  <p className="text-xs text-muted-foreground">What to focus on in the exam</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Selection */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">Choose Subject</h2>
            <p className="text-muted-foreground">Select subject to see revision notes and formulas</p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {/* Mathematics */}
            <Link href="/revision/mathematics">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all flex-shrink-0">
                      <Calculator className="w-7 h-7 text-primary group-hover:text-primary-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Mathematics</CardTitle>
                      <CardDescription>All formulas & important concepts</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• All chapter formulas in one place</li>
                    <li>• Important theorems & properties</li>
                    <li>• Common mistakes to avoid</li>
                    <li>• Quick problem-solving tricks</li>
                  </ul>
                </CardContent>
              </Card>
            </Link>

            {/* Science */}
            <Link href="/revision/science">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-accent group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all flex-shrink-0">
                      <Atom className="w-7 h-7 text-accent group-hover:text-accent-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Science</CardTitle>
                      <CardDescription>Physics, Chemistry, Biology notes</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Important diagrams to remember</li>
                    <li>• Key definitions & concepts</li>
                    <li>• Formula sheet for numericals</li>
                    <li>• Frequently asked topics</li>
                  </ul>
                </CardContent>
              </Card>
            </Link>

            {/* Social Science */}
            <Link href="/revision/social-science">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-chart-3 group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-chart-3/10 flex items-center justify-center group-hover:bg-chart-3 group-hover:scale-110 transition-all flex-shrink-0">
                      <Globe className="w-7 h-7 text-chart-3 group-hover:text-background" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">Social Science</CardTitle>
                      <CardDescription>History dates, Geography, Civics, Economics</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Important dates & events</li>
                    <li>• Key terms & definitions</li>
                    <li>• Map work locations</li>
                    <li>• Chapter-wise summary</li>
                  </ul>
                </CardContent>
              </Card>
            </Link>

            {/* English */}
            <Link href="/revision/english">
              <Card className="h-full transition-all hover:shadow-lg hover:-translate-y-1 border-2 hover:border-chart-4 group">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-chart-4/10 flex items-center justify-center group-hover:bg-chart-4 group-hover:scale-110 transition-all flex-shrink-0">
                      <Languages className="w-7 h-7 text-chart-4 group-hover:text-background" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">English</CardTitle>
                      <CardDescription>Literature, Grammar, Writing formats</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Story & poem summaries</li>
                    <li>• Important grammar rules</li>
                    <li>• Writing formats with examples</li>
                    <li>• Character sketches</li>
                  </ul>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>

        {/* General Exam Tips */}
        <div className="max-w-4xl mx-auto mt-12">
          <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-xl">General Exam Tips for All Subjects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2 text-primary">Before the Exam:</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Get good sleep the night before - don't study late</li>
                    <li>• Keep all your stationery ready (pens, pencils, eraser, scale)</li>
                    <li>• Reach exam center 30 minutes early to avoid stress</li>
                    <li>• Have a light breakfast - don't go on empty stomach</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2 text-accent">During the Exam:</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Read all instructions carefully before starting</li>
                    <li>• Attempt easy questions first to build confidence</li>
                    <li>• Manage time - don't spend too long on one question</li>
                    <li>• Leave some space if you're stuck - come back later</li>
                    <li>• Keep handwriting neat and clean</li>
                    <li>• Review your answers if you have time left</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2 text-chart-3">Smart Answering:</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Underline important keywords in your answers</li>
                    <li>• Draw diagrams wherever required (science, geometry)</li>
                    <li>• Write step-by-step for mathematics problems</li>
                    <li>• Use headings and bullet points for better presentation</li>
                    <li>• Double-check calculations in numerical problems</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
