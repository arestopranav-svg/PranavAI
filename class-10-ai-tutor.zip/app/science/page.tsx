import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Atom, Beaker, Dna, BookOpen, CheckCircle2 } from "lucide-react"

export default function SciencePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center">
                  <Atom className="w-6 h-6 text-accent-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Science</h1>
                  <p className="text-xs text-muted-foreground">Class 10 NCERT</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-accent/5 border-accent/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Welcome to Science</CardTitle>
              <CardDescription className="text-base">
                Science helps you understand how the world works - from tiny atoms to living beings to chemical
                reactions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                <p className="font-semibold text-foreground">Why is Science important?</p>
                <ul className="list-disc list-inside space-y-2 ml-2">
                  <li>Explains everyday phenomena - why it rains, how medicines work, why we breathe</li>
                  <li>Helps you think logically and question things around you</li>
                  <li>Foundation for careers in medicine, engineering, research, technology</li>
                  <li>Makes you aware of your body, environment, and natural processes</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Tabs */}
        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="physics" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="physics" className="flex items-center gap-2">
                <Atom className="w-4 h-4" />
                <span className="hidden sm:inline">Physics</span>
              </TabsTrigger>
              <TabsTrigger value="chemistry" className="flex items-center gap-2">
                <Beaker className="w-4 h-4" />
                <span className="hidden sm:inline">Chemistry</span>
              </TabsTrigger>
              <TabsTrigger value="biology" className="flex items-center gap-2">
                <Dna className="w-4 h-4" />
                <span className="hidden sm:inline">Biology</span>
              </TabsTrigger>
            </TabsList>

            {/* Physics Tab */}
            <TabsContent value="physics">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Physics Chapters</h2>
                <p className="text-muted-foreground">Study of matter, energy, and forces</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 10 - Light */}
                <AccordionItem value="ch-10" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Ch 10</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Light - Reflection and Refraction</h3>
                        <p className="text-sm text-muted-foreground">Mirrors, Lenses, Ray diagrams</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-accent" />
                          What is Light?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Light is energy that allows us to see. It travels in straight lines and can bounce off
                          surfaces (reflection) or bend when passing through different materials (refraction).
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Reflection:</strong> Light bouncing off mirrors (plane, concave, convex)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Refraction:</strong> Light bending when passing through glass, water
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Lenses:</strong> Convex (converging) and Concave (diverging) lenses
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Important Formulas:</h4>
                        <div className="bg-muted p-4 rounded-lg space-y-2 text-sm font-mono">
                          <p>Mirror Formula: 1/f = 1/v + 1/u</p>
                          <p>Magnification: m = -v/u = h'/h</p>
                          <p>Lens Formula: 1/f = 1/v - 1/u</p>
                          <p className="text-xs text-muted-foreground font-sans mt-2">
                            f = focal length, v = image distance, u = object distance
                          </p>
                        </div>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Ray diagrams are VERY important. Practice drawing them for all cases. Remember sign
                          convention: distances measured from pole, against incident ray are negative.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                        <Link href="/science/chapter-10">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 11 - Human Eye */}
                <AccordionItem value="ch-11" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Ch 11</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Human Eye and Colourful World</h3>
                        <p className="text-sm text-muted-foreground">Vision, Defects, Spectrum, Rainbow</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-accent" />
                          How do we see?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Our eye works like a camera. Light enters through the cornea, passes through the lens which
                          focuses it on the retina (like a screen). The brain interprets this as images.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Parts of Eye:</strong> Cornea, Iris, Pupil, Lens, Retina
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Defects:</strong> Myopia (near-sightedness), Hypermetropia (far-sightedness)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Dispersion:</strong> White light splitting into 7 colors (VIBGYOR)
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Diagram of eye is frequently asked. Know which lens corrects which defect: Concave for Myopia,
                          Convex for Hypermetropia. Atmospheric refraction explains twinkling of stars.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                        <Link href="/science/chapter-11">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 12 - Electricity */}
                <AccordionItem value="ch-12" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Ch 12</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Electricity</h3>
                        <p className="text-sm text-muted-foreground">Current, Voltage, Resistance, Circuits</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-accent" />
                          What is Electricity?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Electricity is the flow of electric charge (electrons) through a conductor like a wire. Think
                          of it like water flowing through a pipe.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Important Formulas:</h4>
                        <ul className="space-y-2 text-sm font-mono">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Ohm's Law:</strong> V = I × R
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Power:</strong> P = V × I = I²R = V²/R
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Electrical Energy:</strong> E = P × t
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Series Resistance:</strong> R = R₁ + R₂ + R₃
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          HIGH SCORING chapter with lots of numerical problems. Memorize all formulas. Practice circuit
                          problems - both series and parallel. Know the units: Voltage (V), Current (A), Resistance (Ω).
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                        <Link href="/science/chapter-12">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Physics Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 13</Badge>
                        <span>Magnetic Effects of Electric Current</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 14</Badge>
                        <span>Sources of Energy</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Chemistry Tab */}
            <TabsContent value="chemistry">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Chemistry Chapters</h2>
                <p className="text-muted-foreground">Study of substances, their properties and reactions</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 1 - Chemical Reactions */}
                <AccordionItem value="ch-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-2 text-background">Ch 1</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Chemical Reactions and Equations</h3>
                        <p className="text-sm text-muted-foreground">Types of reactions, Balancing equations</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-2" />
                          What is a Chemical Reaction?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          When substances react and change into different substances. Example: Burning wood converts it
                          to ash and smoke. Iron rusting is also a chemical reaction.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Types of Reactions:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Combination:</strong> Two substances join to form one (A + B → AB)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Decomposition:</strong> One substance breaks into two (AB → A + B)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Displacement:</strong> One element replaces another (A + BC → AC + B)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Redox:</strong> Oxidation (gain of oxygen) & Reduction (loss of oxygen)
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-2/10 border border-chart-2/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Balancing equations is VERY IMPORTANT. Practice writing and balancing at least 20 equations.
                          Remember: atoms on left side = atoms on right side.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-2 text-background hover:bg-chart-2/90" asChild>
                        <Link href="/science/chapter-1">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 2 - Acids Bases Salts */}
                <AccordionItem value="ch-2" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-2 text-background">Ch 2</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Acids, Bases and Salts</h3>
                        <p className="text-sm text-muted-foreground">pH scale, Indicators, Neutralization</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-2" />
                          Simple Explanation
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          <strong>Acids:</strong> Sour taste (lemon, vinegar). Turn blue litmus red.
                          <br />
                          <strong>Bases:</strong> Bitter taste, soapy feel. Turn red litmus blue.
                          <br />
                          <strong>Salts:</strong> Formed when acid reacts with base.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Concepts:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>pH Scale:</strong> 0-14 scale. Less than 7 = Acid, 7 = Neutral, More than 7 = Base
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Neutralization:</strong> Acid + Base → Salt + Water
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-2 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Examples:</strong> HCl (acid), NaOH (base), NaCl (common salt)
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-2/10 border border-chart-2/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Know common acids and bases with their chemical formulas. pH values are frequently asked.
                          Practice writing neutralization reactions with proper equations.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-2 text-background hover:bg-chart-2/90" asChild>
                        <Link href="/science/chapter-2">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Chemistry Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 3</Badge>
                        <span>Metals and Non-metals</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 4</Badge>
                        <span>Carbon and its Compounds</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 5</Badge>
                        <span>Periodic Classification of Elements</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Biology Tab */}
            <TabsContent value="biology">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Biology Chapters</h2>
                <p className="text-muted-foreground">Study of living organisms and life processes</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 6 - Life Processes */}
                <AccordionItem value="ch-6" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-5 text-background">Ch 6</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Life Processes</h3>
                        <p className="text-sm text-muted-foreground">Nutrition, Respiration, Transport, Excretion</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-5" />
                          What are Life Processes?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Basic functions that keep living organisms alive. All living things need food, breathe, remove
                          waste, and transport materials inside their body.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Main Life Processes:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Nutrition:</strong> How organisms get food (autotrophic & heterotrophic)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Respiration:</strong> Breaking down food to release energy (aerobic & anaerobic)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Transportation:</strong> Moving materials around the body (blood, xylem, phloem)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Excretion:</strong> Removing waste products from body (kidneys, lungs)
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-5/10 border border-chart-5/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          LONGEST chapter with many diagrams. Draw and label diagrams of digestive system, heart,
                          nephron, leaf structure. Know the difference between arteries and veins, xylem and phloem.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-5 text-background hover:bg-chart-5/90" asChild>
                        <Link href="/science/chapter-6">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 8 - Heredity */}
                <AccordionItem value="ch-8" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-5 text-background">Ch 8</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">How do Organisms Reproduce?</h3>
                        <p className="text-sm text-muted-foreground">Reproduction in plants and animals</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-5" />
                          What is Reproduction?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Process by which living organisms produce new individuals of their own kind. This ensures
                          continuation of species.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Asexual Reproduction:</strong> Single parent (fission, budding, fragmentation)
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Sexual Reproduction:</strong> Two parents, involves male and female gametes
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-5 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Reproduction in Plants:</strong> Vegetative propagation, flowers, pollination
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-5/10 border border-chart-5/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Diagrams of flower parts and human reproductive system are frequently asked. Know differences
                          between asexual and sexual reproduction. Understand methods of contraception.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-5 text-background hover:bg-chart-5/90" asChild>
                        <Link href="/science/chapter-8">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Biology Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 7</Badge>
                        <span>Control and Coordination</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 9</Badge>
                        <span>Heredity and Evolution</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 15</Badge>
                        <span>Our Environment</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 16</Badge>
                        <span>Sustainable Management of Natural Resources</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>
          </Tabs>
        </div>

        {/* Quick Links */}
        <div className="max-w-4xl mx-auto mt-12 grid sm:grid-cols-2 gap-4">
          <Card className="bg-accent text-accent-foreground">
            <CardHeader>
              <CardTitle>Practice Questions</CardTitle>
              <CardDescription className="text-accent-foreground/80">
                MCQs and problems for Physics, Chemistry, Biology
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/practice/science">Start Practice</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-chart-2 text-background">
            <CardHeader>
              <CardTitle>Quick Revision</CardTitle>
              <CardDescription className="text-background/80">All formulas, diagrams, and key points</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/revision/science">View Revision Notes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
