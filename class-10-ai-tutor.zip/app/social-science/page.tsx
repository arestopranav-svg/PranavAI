import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Globe, MapPin, Users, TrendingUp, BookOpen, CheckCircle2 } from "lucide-react"

export default function SocialSciencePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50 backdrop-blur-sm bg-card/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-chart-3 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-background" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">Social Science</h1>
                  <p className="text-xs text-muted-foreground">Class 10 NCERT</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Introduction */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-chart-3/5 border-chart-3/20">
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Welcome to Social Science</CardTitle>
              <CardDescription className="text-base">
                Learn about history, geography, politics, and economics - understand the world we live in.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                <p className="font-semibold text-foreground">Why is Social Science important?</p>
                <ul className="list-disc list-inside space-y-2 ml-2">
                  <li>Understand past events and how they shape our present</li>
                  <li>Learn about different countries, cultures, and geographical features</li>
                  <li>Know your rights, duties, and how government works</li>
                  <li>Understand money, business, and economic systems</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Tabs */}
        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="history" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-8">
              <TabsTrigger value="history" className="flex items-center gap-2 text-xs sm:text-sm">
                <BookOpen className="w-4 h-4" />
                <span>History</span>
              </TabsTrigger>
              <TabsTrigger value="geography" className="flex items-center gap-2 text-xs sm:text-sm">
                <MapPin className="w-4 h-4" />
                <span>Geography</span>
              </TabsTrigger>
              <TabsTrigger value="civics" className="flex items-center gap-2 text-xs sm:text-sm">
                <Users className="w-4 h-4" />
                <span>Civics</span>
              </TabsTrigger>
              <TabsTrigger value="economics" className="flex items-center gap-2 text-xs sm:text-sm">
                <TrendingUp className="w-4 h-4" />
                <span>Economics</span>
              </TabsTrigger>
            </TabsList>

            {/* History Tab */}
            <TabsContent value="history">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">History - India and the Contemporary World-II</h2>
                <p className="text-muted-foreground">Learn about important events that shaped modern India and world</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 1 - Nationalism in Europe */}
                <AccordionItem value="hist-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-3 text-background">Ch 1</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">The Rise of Nationalism in Europe</h3>
                        <p className="text-sm text-muted-foreground">French Revolution, Napoleon, Unification</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-3" />
                          What is Nationalism?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Nationalism is a feeling of pride and loyalty towards your nation. In 19th century Europe,
                          people wanted freedom from kings and emperors, and wanted to form their own countries.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Events:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>French Revolution (1789):</strong> People overthrew the king, demanded equality
                              and freedom
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Napoleon Bonaparte:</strong> Spread revolutionary ideas across Europe
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Unification of Italy & Germany:</strong> Many small states united to form
                              countries
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Important Terms:</h4>
                        <div className="space-y-2 text-sm">
                          <p>
                            <strong>Liberalism:</strong> Freedom for individuals, equal rights
                          </p>
                          <p>
                            <strong>Conservatism:</strong> Keeping old traditions, resisting change
                          </p>
                          <p>
                            <strong>Nation-state:</strong> A country where most people share culture and identity
                          </p>
                        </div>
                      </div>

                      <div className="bg-chart-3/10 border border-chart-3/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Remember dates of major events. Learn about key personalities - Napoleon, Garibaldi, Bismarck.
                          Map work is important - know locations of Italy, Germany, France.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-3 text-background hover:bg-chart-3/90" asChild>
                        <Link href="/social-science/history-1">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 2 - Nationalism in India */}
                <AccordionItem value="hist-2" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-3 text-background">Ch 2</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Nationalism in India</h3>
                        <p className="text-sm text-muted-foreground">
                          Freedom struggle, Gandhi, Non-cooperation, Civil Disobedience
                        </p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-3" />
                          India's Freedom Struggle
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Indians fought against British rule for almost 100 years. Leaders like Gandhi, Nehru, and
                          others led peaceful protests and movements demanding independence.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Major Movements:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Non-Cooperation Movement (1920-22):</strong> Boycott British goods, schools,
                              courts
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Civil Disobedience (1930):</strong> Salt March, breaking unjust laws
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Quit India Movement (1942):</strong> "Do or Die" - demanding immediate
                              independence
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-3/10 border border-chart-3/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          VERY IMPORTANT chapter - many questions come from here. Remember dates, leaders, and reasons
                          for each movement. Know about Jallianwala Bagh, Chauri Chaura incidents.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-3 text-background hover:bg-chart-3/90" asChild>
                        <Link href="/social-science/history-2">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More History Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 3</Badge>
                        <span>The Making of a Global World</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 4</Badge>
                        <span>The Age of Industrialization</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 5</Badge>
                        <span>Print Culture and Modern World</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Geography Tab */}
            <TabsContent value="geography">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Geography - Contemporary India-II</h2>
                <p className="text-muted-foreground">Resources, agriculture, industries, and economic development</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 1 - Resources and Development */}
                <AccordionItem value="geo-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-primary text-primary-foreground">Ch 1</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Resources and Development</h3>
                        <p className="text-sm text-muted-foreground">Types of resources, Conservation, Land use</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-primary" />
                          What are Resources?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Resources are things from nature that humans can use - water, land, minerals, forests.
                          Everything useful to us is a resource.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Classification of Resources:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Renewable:</strong> Can be renewed - solar energy, wind, water
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Non-renewable:</strong> Limited supply - coal, petroleum, minerals
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Biotic:</strong> Living things - plants, animals
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Abiotic:</strong> Non-living - rocks, metals, minerals
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Know different types of resources with examples. Soil types and their distribution in India is
                          important. Practice map work - locating soil types, land use patterns.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto" asChild>
                        <Link href="/social-science/geography-1">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 3 - Water Resources */}
                <AccordionItem value="geo-3" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-primary text-primary-foreground">Ch 3</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Water Resources</h3>
                        <p className="text-sm text-muted-foreground">Dams, Rainwater harvesting, Water scarcity</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-primary" />
                          Why is Water Important?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Water is essential for life. We use it for drinking, farming, industries. But clean water is
                          becoming scarce due to pollution and overuse.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Dams:</strong> Multipurpose projects - irrigation, electricity, flood control
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Rainwater Harvesting:</strong> Collecting and storing rainwater for future use
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Water Scarcity:</strong> Causes and solutions
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-primary/10 border border-primary/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Know advantages and disadvantages of dams. Understand different methods of rainwater
                          harvesting. Map work - major dams and river valley projects in India.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto" asChild>
                        <Link href="/social-science/geography-3">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Geography Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 2</Badge>
                        <span>Forest and Wildlife Resources</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 4</Badge>
                        <span>Agriculture</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 5</Badge>
                        <span>Minerals and Energy Resources</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 6</Badge>
                        <span>Manufacturing Industries</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 7</Badge>
                        <span>Lifelines of National Economy - Transport & Communication</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Civics Tab */}
            <TabsContent value="civics">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Civics - Democratic Politics-II</h2>
                <p className="text-muted-foreground">Democracy, government, and political systems</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 1 - Power Sharing */}
                <AccordionItem value="civ-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-4 text-background">Ch 1</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Power Sharing</h3>
                        <p className="text-sm text-muted-foreground">Why and how power is shared in democracy</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-4" />
                          What is Power Sharing?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          In democracy, power is not kept by one person or group. It is shared among different people,
                          groups, and institutions so no one becomes too powerful.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Forms of Power Sharing:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Horizontal:</strong> Between Legislature, Executive, Judiciary
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Vertical:</strong> Between different levels - Central, State, Local government
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Social Groups:</strong> Among different social, linguistic, religious groups
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-4/10 border border-chart-4/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Understand examples from Belgium and Sri Lanka. Know the difference between horizontal and
                          vertical power sharing with examples.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-4 text-background hover:bg-chart-4/90" asChild>
                        <Link href="/social-science/civics-1">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 3 - Democracy and Diversity */}
                <AccordionItem value="civ-3" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-chart-4 text-background">Ch 3</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Democracy and Diversity</h3>
                        <p className="text-sm text-muted-foreground">Social divisions, Caste, Religion in politics</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-chart-4" />
                          Diversity in Democracy
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          India has people of many religions, castes, languages. Democracy must respect all groups and
                          give everyone equal rights and opportunities.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Concepts:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Social Divisions:</strong> Differences based on caste, religion, language
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Politics of Social Division:</strong> How political parties use caste/religion
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-chart-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Secularism:</strong> No official religion, equal respect for all religions
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-chart-4/10 border border-chart-4/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Important for understanding Indian politics. Know what communalism means. Understand why caste
                          and religion should not decide politics.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-chart-4 text-background hover:bg-chart-4/90" asChild>
                        <Link href="/social-science/civics-3">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Civics Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 2</Badge>
                        <span>Federalism</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 4</Badge>
                        <span>Gender, Religion and Caste</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 5</Badge>
                        <span>Popular Struggles and Movements</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 6</Badge>
                        <span>Political Parties</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 7</Badge>
                        <span>Outcomes of Democracy</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>

            {/* Economics Tab */}
            <TabsContent value="economics">
              <div className="mb-6">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Economics - Understanding Economic Development</h2>
                <p className="text-muted-foreground">Money, development, trade, and economic systems</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {/* Chapter 1 - Development */}
                <AccordionItem value="eco-1" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Ch 1</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Development</h3>
                        <p className="text-sm text-muted-foreground">Income, HDI, Sustainability</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-accent" />
                          What is Development?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Development means progress and improvement in living standards. It's not just about money, but
                          also health, education, and quality of life.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Concepts:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Per Capita Income:</strong> Average income per person in a country
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>HDI (Human Development Index):</strong> Measures health, education, income
                              together
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Sustainability:</strong> Development without harming future generations
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Know how to calculate Per Capita Income. Understand why income alone is not enough to measure
                          development. Learn components of HDI.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                        <Link href="/social-science/economics-1">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* Chapter 3 - Money and Credit */}
                <AccordionItem value="eco-3" className="border rounded-lg px-4 bg-card">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-start gap-3 text-left">
                      <Badge className="mt-1 bg-accent text-accent-foreground">Ch 3</Badge>
                      <div>
                        <h3 className="font-semibold text-lg">Money and Credit</h3>
                        <p className="text-sm text-muted-foreground">Modern money, Banks, Loans, Interest</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pt-4 space-y-4">
                    <div className="space-y-4 pl-2">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-accent" />
                          How does Money Work?
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Money is a medium of exchange. Earlier people used barter (exchanging goods). Now we use
                          currency notes and digital money. Banks help us save money and get loans.
                        </p>
                      </div>

                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Functions of Money:</strong> Medium of exchange, Store of value, Unit of account
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Banks:</strong> Accept deposits, give loans, create credit
                            </div>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                            <div>
                              <strong>Formal vs Informal Credit:</strong> Banks/cooperatives vs moneylenders
                            </div>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-accent/10 border border-accent/20 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2 text-accent-foreground">Exam Tip:</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          Understand how banks create credit (multiply money). Know problems with informal credit - high
                          interest rates, debt trap. Double coincidence of wants is a key term.
                        </p>
                      </div>

                      <Button className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90" asChild>
                        <Link href="/social-science/economics-3">View Full Chapter</Link>
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                {/* More Economics Chapters */}
                <Card className="bg-muted/50">
                  <CardContent className="pt-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 2</Badge>
                        <span>Sectors of Indian Economy</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 4</Badge>
                        <span>Globalization and Indian Economy</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Ch 5</Badge>
                        <span>Consumer Rights</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Accordion>
            </TabsContent>
          </Tabs>
        </div>

        {/* Quick Links */}
        <div className="max-w-4xl mx-auto mt-12 grid sm:grid-cols-2 gap-4">
          <Card className="bg-chart-3 text-background">
            <CardHeader>
              <CardTitle>Practice Questions</CardTitle>
              <CardDescription className="text-background/80">Test your knowledge of all four subjects</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/practice/social-science">Start Practice</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-chart-4 text-background">
            <CardHeader>
              <CardTitle>Quick Revision</CardTitle>
              <CardDescription className="text-background/80">Important dates, terms, and concepts</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" className="w-full" asChild>
                <Link href="/revision/social-science">View Revision Notes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
